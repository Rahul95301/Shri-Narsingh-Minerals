# Shrinar Singh Minerals — Full‑stack site (Next.js + Prisma + SQLite)

## Quick Start
1. Install Node 18+ and NPM.
2. `cp .env.example .env` then edit values.
3. `npm install`
4. Initialize DB: `npx prisma db push`
5. Run dev: `npm run dev` → http://localhost:3000

## Cheap Hosting
- **Vercel (Free)** for frontend + API. Use Neon/Supabase (Free) if you outgrow SQLite.
- **Hostinger** Node app: upload build, set environment vars, start with `npm start`.
- **Render (Free)** can host Node and persist SQLite with a disk.

## Admin
Open `/admin?token=YOUR_ACCESS_TOKEN` to view/export CSV of leads.

## Email
Optional Resend integration. Set `RESEND_API_KEY`, `NOTIFY_TO`, `NOTIFY_FROM`.

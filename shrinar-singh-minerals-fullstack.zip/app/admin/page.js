export const dynamic = "force-dynamic";
async function getData(token) {
  const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL || ""}/api/enquiry?token=${encodeURIComponent(token)}`, { cache:"no-store" });
  if (!res.ok) return { ok:false, list:[] };
  return res.json();
}
function toCSV(list){ const head=["id","name","email","phone","message","createdAt"];
  const rows=list.map(x=>[x.id,x.name,x.email||"",x.phone,JSON.stringify(x.message).slice(1,-1),new Date(x.createdAt).toISOString()]);
  return [head.join(","),...rows.map(r=>r.join(","))].join("\n"); }
export default async function Admin({ searchParams }){
  const token = searchParams.token || "";
  const data = token ? await getData(token) : { ok:false, list:[] };
  const csv = data.ok ? toCSV(data.list) : "";
  return (<div className="container py-10">
    <h1 className="text-2xl font-bold">Admin — Leads</h1>
    <p className="text-sm text-zinc-400">Append <code>?token=YOUR_ACCESS_TOKEN</code> to access.</p>
    {data.ok ? (<div className="mt-6">
      <div className="mb-3 text-sm text-zinc-400">{data.list.length} enquiries</div>
      <div className="overflow-x-auto border border-white/10 rounded-xl">
        <table className="min-w-[720px] text-sm">
          <thead className="text-left text-zinc-400"><tr>
            <th className="px-3 py-2">#</th><th className="px-3 py-2">Name</th><th className="px-3 py-2">Phone</th><th className="px-3 py-2">Email</th><th className="px-3 py-2">Message</th><th className="px-3 py-2">Time</th>
          </tr></thead>
          <tbody>{data.list.map(x=>(
            <tr key={x.id} className="border-t border-white/10 align-top">
              <td className="px-3 py-2">{x.id}</td>
              <td className="px-3 py-2 font-medium">{x.name}</td>
              <td className="px-3 py-2">{x.phone}</td>
              <td className="px-3 py-2">{x.email || "-"}</td>
              <td className="px-3 py-2 whitespace-pre-wrap">{x.message}</td>
              <td className="px-3 py-2 text-zinc-400">{new Date(x.createdAt).toLocaleString()}</td>
            </tr>
          ))}</tbody>
        </table>
      </div>
      <form method="post" action={`data:text/csv;charset=utf-8,${encodeURIComponent(csv)}`} className="mt-4">
        <button className="btn">Download CSV</button>
      </form>
    </div>) : (<div className="mt-6 text-red-400">Unauthorized or missing token.</div>)}
  </div>);
}

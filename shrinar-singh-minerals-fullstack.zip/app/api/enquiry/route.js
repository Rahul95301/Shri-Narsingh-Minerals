import { prisma } from "@/lib/prisma";
import { z } from "zod";
import { sendLeadEmail } from "@/lib/email";

const schema = z.object({
  name: z.string().min(2),
  phone: z.string().min(6),
  email: z.string().email().optional().or(z.literal("")),
  message: z.string().min(5),
});

export async function POST(req) {
  try {
    const body = await req.json();
    const data = schema.parse(body);
    const ua = req.headers.get("user-agent") || "";
    const ip = req.headers.get("x-forwarded-for") || req.ip || "";
    const row = await prisma.enquiry.create({
      data: {
        name: data.name,
        email: data.email || null,
        phone: data.phone,
        message: data.message,
        sourceIp: String(ip),
        userAgent: ua,
      },
    });
    sendLeadEmail(data).catch(() => {});
    return Response.json({ ok: true, id: row.id });
  } catch (e) {
    return new Response(JSON.stringify({ ok:false, error: String(e) }), { status: 400 });
  }
}

export async function GET(req) {
  const url = new URL(req.url);
  const token = url.searchParams.get("token") || req.headers.get("x-access-token");
  if (!token || token !== process.env.ACCESS_TOKEN) {
    return new Response(JSON.stringify({ ok:false, error: "Unauthorized" }), { status: 401 });
  }
  const list = await prisma.enquiry.findMany({ orderBy: { createdAt: "desc" } });
  return Response.json({ ok:true, list });
}

export const metadata = {
  title: "Shrinar Singh Minerals — Quartz & Feldspar | Rajasthan",
  description: "Supplier/exporter of Quartz & Feldspar from Tonk–Newai with deliveries across Jaipur region.",
};
import "./globals.css";
export default function RootLayout({ children }) {
  return (<html lang="en"><body>{children}</body></html>);
}

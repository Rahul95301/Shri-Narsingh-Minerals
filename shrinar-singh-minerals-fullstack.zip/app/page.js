import Header from "@/components/Header";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <main>
      <Header />
      <section className="relative">
        <div className="absolute inset-0 bg-[radial-gradient(60%_60%_at_20%_10%,rgba(239,68,68,.25),transparent_60%)]" />
        <Hero />
      </section>
      <Products />
      <Quality />
      <Operations />
      <Locations />
      <CTA />
      <Contact />
      <Footer />
    </main>
  );
}

function Hero() {
  return (
    <div className="container pt-16 pb-12 md:pt-24 md:pb-24">
      <div className="grid md:grid-cols-2 gap-10 items-center">
        <div>
          <p className="text-zinc-300 text-sm mb-2">Export • Supply • Logistics</p>
          <h1 className="text-4xl md:text-5xl font-black tracking-tight leading-tight">
            High‑Purity <span className="text-red-500">Quartz</span> & Feldspar from Rajasthan
          </h1>
          <p className="mt-4 text-zinc-300/90 max-w-prose">
            Sourcing and logistics partner for quartz (snow white & industrial) and feldspar. Stock yard at
            <span className="font-semibold"> Tonk–Newai</span>. Timely deliveries across Jaipur, Kishangarh, Dudu, Bagru and beyond.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <a href="#products" className="btn btn-primary">View Products</a>
            <a href="#contact" className="btn">Get a Quote</a>
          </div>
          <div className="mt-6 text-xs text-zinc-400">
            GST: <span className="font-mono">XXABCDE1234Z5ZQ</span> • IEC: <span className="font-mono">IMPORT‑CODE‑1234</span> (placeholders)
          </div>
        </div>
        <div className="relative">
          <div className="aspect-[4/3] card overflow-hidden grid place-items-center">
            <span className="text-zinc-500">Illustration / Photo Placeholder</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function SectionTitle({ children, action }) {
  return (
    <div className="flex items-end justify-between gap-6 mb-8">
      <h2 className="text-2xl md:text-3xl font-extrabold">{children}</h2>
      {action}
    </div>
  );
}

function Products() {
  const products = [
    { name: "Quartz (Snow White)", desc: "High‑purity snow white quartz for engineered stone, glass and ceramics.", specs: ["SiO₂ > 98–99.5%", "Fe₂O₃ < 0.08%", "Whiteness 92–98%"], sizes: "0–5 mm, 5–10 mm, 10–40 mm; powders on order" },
    { name: "Quartz (Industrial)", desc: "Consistent industrial grade quartz for foundry, refractories and ramming mass.", specs: ["SiO₂ > 97%", "Moisture < 0.5%", "Low alkali"], sizes: "10–80 mm; graded as required" },
    { name: "Feldspar (Soda / Potash)", desc: "Ceramic‑grade feldspar for vitrified tiles, sanitary ware and glass.", specs: ["K₂O / Na₂O 8–12%", "Fe₂O₃ < 0.3%"], sizes: "10–75 mm; powder on request" },
  ];
  return (
    <section id="products" className="border-t border-white/10 bg-zinc-950/50">
      <div className="container py-16">
        <SectionTitle action={<a href="#contact" className="text-sm text-red-400 hover:text-red-300">Request current prices →</a>}>Products & Grades</SectionTitle>
        <div className="grid md:grid-cols-3 gap-6">
          {products.map((p) => (
            <article key={p.name} className="card p-6">
              <h3 className="font-black text-lg">{p.name}</h3>
              <p className="mt-2 text-sm text-zinc-300/90">{p.desc}</p>
              <div className="mt-3 text-sm">
                <div className="font-semibold text-zinc-200">Typical Specs</div>
                <ul className="mt-1 list-disc list-inside text-zinc-300/90 space-y-1">
                  {p.specs.map((s) => <li key={s}>{s}</li>)}
                </ul>
              </div>
              <div className="mt-3 text-sm">
                <div className="font-semibold text-zinc-200">Available Sizes</div>
                <p className="text-zinc-300/90">{p.sizes}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

function Quality() {
  return (
    <section id="quality" className="border-t border-white/10">
      <div className="container py-16">
        <div className="grid md:grid-cols-2 gap-10 items-start">
          <div>
            <h2 className="text-2xl md:text-3xl font-extrabold">Quality & Consistency</h2>
            <ul className="mt-4 space-y-3 text-zinc-300/90 list-disc list-inside">
              <li>Vetted leases around Tonk–Newai belt.</li>
              <li>Manual and mechanical screening for controlled sizes.</li>
              <li>Random sampling for Fe₂O₃ and moisture checks.</li>
              <li>Covered transport to maintain whiteness when required.</li>
              <li>Proof of delivery and weighbridge slips shared digitally.</li>
            </ul>
            <div className="mt-6 p-4 card text-sm">
              <div className="font-semibold">Certifications & Documents</div>
              <p className="text-zinc-300/90">GST Invoice • E‑way Bill • Test Reports (on lot) • IEC for export shipments.</p>
            </div>
          </div>
          <div className="card p-6">
            <h3 className="font-bold">Industries Served</h3>
            <div className="mt-3 grid grid-cols-2 gap-3 text-sm text-zinc-300/90">
              {["Engineered Stone","Tiles & Ceramics","Glass Works","Foundry & Refractories","Ramming Mass","Paints & Coatings"].map((i) => (
                <div key={i} className="rounded-xl border border-white/10 bg-zinc-950/60 px-3 py-2">{i}</div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Operations() {
  const routes = [
    { from: "Tonk Newai", to: "Jaipur", kms: 65, time: "1.5–2 hrs" },
    { from: "Tonk Newai", to: "Kishangarh", kms: 95, time: "2–2.5 hrs" },
    { from: "Tonk Newai", to: "Dudu", kms: 80, time: "1.5–2 hrs" },
    { from: "Tonk Newai", to: "Bagru", kms: 50, time: "1–1.5 hrs" },
  ];
  const cards = [
    { t: "Stock Yard", d: "Tonk–Newai yard with space for segregated piling and loading." },
    { t: "Sizing", d: "Lumps sizing 0–5, 5–10, 10–40, 10–80 mm. Powder via partners." },
    { t: "Fleet", d: "Network of 10T–20T tippers, tractor‑trolleys for short hauls." },
    { t: "Dispatch", d: "24–72 hour turnaround depending on route and lot size." },
    { t: "Digital", d: "Live updates, e‑docs, weighbridge slips over WhatsApp/Email." },
    { t: "Safety", d: "Tarpaulin covering on request to preserve whiteness." },
  ];
  return (
    <section id="operations" className="border-t border-white/10 bg-zinc-950/40">
      <div className="container py-16">
        <h2 className="text-2xl md:text-3xl font-extrabold">Operations & Capacity</h2>
        <div className="mt-6 grid md:grid-cols-3 gap-6">
          {cards.map((x) => (
            <div key={x.t} className="card p-5">
              <div className="font-bold">{x.t}</div>
              <div className="text-sm text-zinc-300/90">{x.d}</div>
            </div>
          ))}
        </div>
        <div className="mt-10 overflow-x-auto">
          <table className="min-w-[520px] text-sm">
            <thead className="text-left text-zinc-400">
              <tr>
                <th className="px-3 py-2">From</th>
                <th className="px-3 py-2">To</th>
                <th className="px-3 py-2">Distance (km)</th>
                <th className="px-3 py-2">Typical Time</th>
              </tr>
            </thead>
            <tbody>
              {routes.map((r) => (
                <tr key={r.to} className="border-b border-white/10">
                  <td className="px-3 py-2">{r.from}</td>
                  <td className="px-3 py-2">{r.to}</td>
                  <td className="px-3 py-2">{r.kms}</td>
                  <td className="px-3 py-2">{r.time}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}

function Locations() {
  const coverage = ["Tonk–Newai (Stock Yard)","Bagru","Jaipur (Sitapura/VKI/Murlipura/Mansarovar)","Kishangarh","Dudu","Tikawara"];
  return (
    <section id="locations" className="border-t border-white/10">
      <div className="container py-16">
        <div className="grid md:grid-cols-2 gap-10 items-start">
          <div>
            <h2 className="text-2xl md:text-3xl font-extrabold">Locations & Coverage</h2>
            <p className="mt-3 text-zinc-300/90">
              Stock located at <span className="font-semibold">Tonk–Newai</span>. We supply across Jaipur,
              Kishangarh, Dudu, Tikawara, Bagru and nearby industrial areas. For export, we facilitate container
              loading from ICDs in Jaipur and nearby.
            </p>
            <ul className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm">
              {coverage.map((c) => <li key={c} className="rounded-xl border border-white/10 bg-zinc-900/60 px-3 py-2">{c}</li>)}
            </ul>
          </div>
          <div className="card p-4">
            <div className="text-sm text-zinc-400 mb-2">Map placeholder (replace with Google Map)</div>
            <div className="aspect-[4/3] rounded-2xl bg-zinc-950 border border-white/10 grid place-items-center">
              <span className="text-zinc-500">Tonk → Jaipur/Kishangarh/Bagru/Dudu</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function CTA() {
  return (
    <section className="border-y border-white/10 bg-gradient-to-b from-zinc-900/60 to-zinc-950/60">
      <div className="container py-14 text-center">
        <h3 className="text-2xl md:text-3xl font-extrabold">Need steady Quartz & Feldspar supply?</h3>
        <p className="mt-2 text-zinc-300/90">Share your monthly requirement, specs and destination. We will revert with prices and dispatch timelines.</p>
        <div className="mt-5 flex justify-center gap-3">
          <a href="#contact" className="btn btn-primary">Send RFQ</a>
          <a href="mailto:sales@shrinarminerals.com?subject=RFQ%20-%20Quartz&body=Hello%2C%20we%20require..." className="btn">Email Us</a>
        </div>
      </div>
    </section>
  );
}

async function sendEnquiry(fd) {
  const res = await fetch("/api/enquiry", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(Object.fromEntries(fd)),
  });
  return res.json();
}

function Contact() {
  return (
    <section id="contact" className="border-b border-white/10">
      <div className="container py-16">
        <div className="grid md:grid-cols-2 gap-10">
          <div>
            <h2 className="text-2xl md:text-3xl font-extrabold">Contact & Enquiries</h2>
            <div className="mt-4 space-y-2 text-zinc-300/90 text-sm">
              <div><span className="text-zinc-400">Phone:</span> +91‑98XX‑XXXXXX</div>
              <div><span className="text-zinc-400">Email:</span> sales@shrinarminerals.com</div>
              <div><span className="text-zinc-400">Yard:</span> Tonk–Newai, Rajasthan</div>
              <div><span className="text-zinc-400">Office:</span> Jaipur, Rajasthan</div>
            </div>
            <div className="mt-5 text-sm text-zinc-400">Business hours: Mon–Sat, 9:30 AM–6:30 PM</div>
          </div>
          <form className="card p-6" onSubmit={async (e) => {
            e.preventDefault();
            const btn = e.currentTarget.querySelector("button[type='submit']");
            btn.disabled = True; btn.textContent = "Sending...";
            const fd = new FormData(e.currentTarget);
            const out = await sendEnquiry(fd);
            btn.disabled = false; btn.textContent = "Submit Enquiry";
            alert(out.ok ? "Thanks! We will contact you shortly." : `Error: ${out.error}`);
            if (out.ok) e.currentTarget.reset();
          }}>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="name">Your Name</label>
                <input id="name" name="name" required />
              </div>
              <div>
                <label htmlFor="phone">Phone / WhatsApp</label>
                <input id="phone" name="phone" required />
              </div>
              <div className="sm:col-span-2">
                <label htmlFor="email">Email</label>
                <input id="email" name="email" type="email" />
              </div>
              <div className="sm:col-span-2">
                <label htmlFor="message">Requirement</label>
                <textarea id="message" name="message" rows={5} required placeholder="Material, quantity/month, destination, specs…" />
              </div>
            </div>
            <div className="mt-4 flex gap-3">
              <button type="submit" className="btn btn-primary">Submit Enquiry</button>
              <a href="https://wa.me/919999999999?text=Hello%2C%20we%20need%20Quartz%2FFeldspar" target="_blank" rel="noreferrer" className="btn">WhatsApp</a>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
}

export default function Footer() {
  return (
    <footer className="py-10 border-t border-white/10">
      <div className="container flex flex-col md:flex-row items-start md:items-center justify-between gap-6 text-sm text-zinc-400">
        <div>© {new Date().getFullYear()} Shrinar Singh Minerals. All rights reserved.</div>
        <div className="flex flex-wrap gap-4">
          <a className="hover:text-zinc-200" href="#">GST & Compliance</a>
          <a className="hover:text-zinc-200" href="#">Quality Policy</a>
          <a className="hover:text-zinc-200" href="#">Privacy</a>
          <a className="hover:text-zinc-200" href="#">Terms</a>
        </div>
      </div>
    </footer>
  );
}

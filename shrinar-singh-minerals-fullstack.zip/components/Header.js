export default function Header() {
  return (
    <header className="sticky top-0 z-40 backdrop-blur bg-black/30 border-b border-white/10">
      <div className="container h-16 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-red-600 to-red-800 shadow-lg" />
          <div className="font-extrabold tracking-wide text-lg">
            Shrinar Singh <span className="text-red-500">Minerals</span>
          </div>
        </div>
        <nav className="hidden md:flex items-center gap-6 text-sm text-zinc-300">
          <a href="#products" className="hover:text-white">Products</a>
          <a href="#quality" className="hover:text-white">Quality</a>
          <a href="#operations" className="hover:text-white">Operations</a>
          <a href="#locations" className="hover:text-white">Locations</a>
          <a href="#contact" className="hover:text-white">Contact</a>
        </nav>
        <a href="https://wa.me/919999999999?text=Hello%2C%20I%20need%20Quartz%2FFeldspar" target="_blank" rel="noreferrer"
           className="hidden sm:inline-flex btn btn-primary">WhatsApp</a>
      </div>
    </header>
  );
}
